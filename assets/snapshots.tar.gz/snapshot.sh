#!/bin/bash

export PATH=$PWD/usr/bin/:$PATH
export LD_LIBRARY_PATH=$PWD/usr/lib/aarch64-linux-gnu/
export GST_PLUGIN_PATH=$PWD/usr/lib/aarch64-linux-gnu/gstreamer-1.0/

usage() {
    echo "Usage: $0 [-i] [-s] [-d]"
    echo "  -i    Initialize pipelines"
    echo "  -s    Take snapshots"
    echo "  -d    Deinitialize pipelines"
    echo ""
    echo "Examples:"
    echo "   Start the pipelines"
    echo "   $0 -i"
    echo ""
    echo "   Stop the pipelines"
    echo "   $0 -d"
    echo ""
    echo "   Take snapshots"
    echo "   $0 -s"
    exit 1;
}

while getopts "isd" o; do
    case "${o}" in
        i) INIT=1;;
        s) SNAPSHOT=1;;
        d) DEINIT=1;;
        *) usage;;
    esac
done
shift $((OPTIND-1))

function init_pipelines {
    gstd -e -l $PWD/gstd.log -d $PWD/gst.log -f /tmp/

    # NOTE: set the caps' resolution twice (as done below) is not necessary, but keep it like this to be explicit
    # Create capture pipelines
    gst-client-1.0 pipeline_create cameras \
        nvarguscamerasrc sensor-id=0 ! "video/x-raw(memory:NVMM),width=1280,height=720" ! nvvidconv ! "video/x-raw,width=1280,height=720,format=RGBA" ! queue leaky=2 max-size-buffers=1 ! interpipesink name=cam0 async=false \
        nvarguscamerasrc sensor-id=1 ! "video/x-raw(memory:NVMM),width=1280,height=720" ! nvvidconv ! "video/x-raw,width=1280,height=720,format=RGBA" ! queue leaky=2 max-size-buffers=1 ! interpipesink name=cam1 async=false \
        nvarguscamerasrc sensor-id=2 ! "video/x-raw(memory:NVMM),width=1280,height=720" ! nvvidconv ! "video/x-raw,width=1280,height=720,format=RGBA" ! queue leaky=2 max-size-buffers=1 ! interpipesink name=cam2 async=false \
        nvarguscamerasrc sensor-id=3 ! "video/x-raw(memory:NVMM),width=1280,height=720" ! nvvidconv ! "video/x-raw,width=1280,height=720,format=RGBA" ! queue leaky=2 max-size-buffers=1 ! interpipesink name=cam3 async=false \
        nvarguscamerasrc sensor-id=4 ! "video/x-raw(memory:NVMM),width=1280,height=720" ! nvvidconv ! "video/x-raw,width=1280,height=720,format=RGBA" ! queue leaky=2 max-size-buffers=1 ! interpipesink name=cam4 async=false \
        nvarguscamerasrc sensor-id=5 ! "video/x-raw(memory:NVMM),width=1280,height=720" ! nvvidconv ! "video/x-raw,width=1280,height=720,format=RGBA" ! queue leaky=2 max-size-buffers=1 ! interpipesink name=cam5 async=false \
        nvarguscamerasrc sensor-id=6 ! "video/x-raw(memory:NVMM),width=1280,height=720" ! nvvidconv ! "video/x-raw,width=1280,height=720,format=RGBA" ! queue leaky=2 max-size-buffers=1 ! interpipesink name=cam6 async=false \
        nvarguscamerasrc sensor-id=7 ! "video/x-raw(memory:NVMM),width=1280,height=720" ! nvvidconv ! "video/x-raw,width=1280,height=720,format=RGBA" ! queue leaky=2 max-size-buffers=1 ! interpipesink name=cam7 async=false

    # Create snapshots pipelines
    gst-client-1.0 pipeline_create snapshots \
        interpipesrc num-buffers=1 is-live=true stream-sync=0 listen-to=cam0 ! nvvidconv ! pngenc ! filesink location=$PWD/snapshot0.png async=false \
        interpipesrc num-buffers=1 is-live=true stream-sync=0 listen-to=cam1 ! nvvidconv ! pngenc ! filesink location=$PWD/snapshot1.png async=false \
        interpipesrc num-buffers=1 is-live=true stream-sync=0 listen-to=cam2 ! nvvidconv ! pngenc ! filesink location=$PWD/snapshot2.png async=false \
        interpipesrc num-buffers=1 is-live=true stream-sync=0 listen-to=cam3 ! nvvidconv ! pngenc ! filesink location=$PWD/snapshot3.png async=false \
        interpipesrc num-buffers=1 is-live=true stream-sync=0 listen-to=cam4 ! nvvidconv ! pngenc ! filesink location=$PWD/snapshot4.png async=false \
        interpipesrc num-buffers=1 is-live=true stream-sync=0 listen-to=cam5 ! nvvidconv ! pngenc ! filesink location=$PWD/snapshot5.png async=false \
        interpipesrc num-buffers=1 is-live=true stream-sync=0 listen-to=cam6 ! nvvidconv ! pngenc ! filesink location=$PWD/snapshot6.png async=false \
        interpipesrc num-buffers=1 is-live=true stream-sync=0 listen-to=cam7 ! nvvidconv ! pngenc ! filesink location=$PWD/snapshot7.png async=false

    # Play capture pipelines
    gst-client-1.0 pipeline_play cameras
}

function deinit_pipelines {
    # Clean resources
    gst-client-1.0 pipeline_delete snapshots
    gst-client-1.0 pipeline_delete cameras

    gstd -k -f /tmp/
}

function take_snapshots {
    gst-client-1.0 pipeline_stop snapshots
    gst-client-1.0 pipeline_play snapshots
}

# Trigger action
if [ ! -z "${INIT}" ]; then
    init_pipelines
elif [ ! -z "${DEINIT}" ]; then
    deinit_pipelines
elif [ ! -z "${SNAPSHOT}" ]; then
    take_snapshots
fi

