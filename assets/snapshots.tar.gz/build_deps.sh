#!/bin/bash

OUT_DIR=$PWD/

set -e

sudo apt-get install \
automake \
libtool \
pkg-config \
libgstreamer1.0-dev \
libgstreamer-plugins-base1.0-dev \
libglib2.0-dev \
libjson-glib-dev \
gtk-doc-tools \
libreadline-dev \
libncursesw5-dev \
libdaemon-dev \
libjansson-dev \
libsoup2.4-dev \
python3-pip \
libedit-dev

mkdir -p $OUT_DIR

git clone https://github.com/RidgeRun/gst-interpipe.git
cd gst-interpipe
./autogen.sh --prefix $OUT_DIR/usr/ --libdir $OUT_DIR/usr/lib/aarch64-linux-gnu/
make
make install

cd ..
git clone https://github.com/RidgeRun/gstd-1.x.git
cd gstd-1.x
./autogen.sh
./configure --prefix $OUT_DIR/usr/ --libdir $OUT_DIR/usr/lib/aarch64-linux-gnu/
make
sudo make install


